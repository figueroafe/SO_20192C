#include <stdio.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[])
{
    int sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0)
    {
        printf("Error: No se pudo crear el socket.");
        return 1;
    }

    char recvBuff[1024];
    char sendBuff[1024];
    memset(recvBuff, '0',sizeof(recvBuff));
    memset(sendBuff, '0',sizeof(sendBuff));

    struct sockaddr_in serv_addr;
    memset(&serv_addr, '0', sizeof(serv_addr));
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(atoi(argv[2]));
    serv_addr.sin_addr.s_addr = inet_addr(argv[1]);
    inet_pton(AF_INET, argv[1], &serv_addr.sin_addr); // Error si IP mal escrita

    if ( connect(sockfd, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) < 0)
    {
       printf("Error: No se pudo conectar\n");
       return 1;
    }

    while(1)
    {

        printf("Ingrese una consulta: \n");
        scanf("%s", sendBuff);
        write(sockfd, sendBuff, strlen((sendBuff)-1));
        memset(sendBuff, '0',sizeof(sendBuff));
        read(sockfd, recvBuff, strlen((recvBuff)-1));
    //    read(sockfd, recvBuff, strlen((recvBuff)-1));
        printf("%s", recvBuff);
        memset(recvBuff, '0',sizeof(recvBuff));
        sleep(1);
    }
    return 0;
}
