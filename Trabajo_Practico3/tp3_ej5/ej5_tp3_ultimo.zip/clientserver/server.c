#include <stdio.h>
#include <string.h>
#include <time.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>

int main()
{
    struct sockaddr_in serv_addr;
    char sendBuff[1025];
    char recevBuff[1025];
    memset(sendBuff, '0', sizeof(sendBuff));
    memset(recevBuff, '0', sizeof(recevBuff));
    memset(&serv_addr, '0', sizeof(serv_addr));

    serv_addr.sin_family = AF_INET;
    serv_addr.sin_addr.s_addr = htonl(INADDR_ANY);
    serv_addr.sin_port = htons(7000);

    int listenfd = socket(AF_INET, SOCK_STREAM, 0);
    bind(listenfd, (struct sockaddr*)&serv_addr, sizeof(serv_addr));

    listen(listenfd, 10);

    int connfd = accept(listenfd, (struct sockaddr*)NULL, NULL),
        connfd2 = accept(listenfd, (struct sockaddr*)NULL, NULL);
  //  write(connfd, "Conexion Establecida...\n", 30);
    //snprintf(sendBuff, sizeof(sendBuff), "Hola conexion %d", connfd );

    while (1)
    {
        read(connfd, recevBuff, 100/*strlen((recevBuff)-1)*/);
        printf("Llego %s de la conexion %d\n", recevBuff, connfd);
     //   memset(recevBuff, '0', sizeof(recevBuff));
        write(connfd, "Tu mensaje ha sido recibido\n", 50);
        memset(sendBuff, '0', sizeof(sendBuff));

        read(connfd2, recevBuff, 100/*strlen((recevBuff)-1)*/);
        printf("Llego %s de la conexion %d\n", recevBuff, connfd2);
     //   memset(recevBuff, '0', sizeof(recevBuff));
        write(connfd2, "Tu mensaje ha sido recibido\n", 50);
        memset(sendBuff, '0', sizeof(sendBuff));
        sleep(1);
    }
    close(connfd);
}
