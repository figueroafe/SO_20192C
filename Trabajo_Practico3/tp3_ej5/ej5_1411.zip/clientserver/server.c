#include <stdio.h>
#include <string.h>
#include <time.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <sys/stat.h>
#include <stdlib.h>
#include <fcntl.h>
#include <errno.h>
#include <unistd.h>
#include <syslog.h>

int main()
{
    pid_t pid, sid;
    pid = fork();
    if (pid != 0)
    {
    exit(1);
    }
    else
    {
        umask(0);
        sid = setsid();

        if (sid < 0) {
        perror("new SID failed");
        exit(EXIT_FAILURE);
        }

        chdir("/home");
        close(STDIN_FILENO);
        close(STDOUT_FILENO);
        close(STDERR_FILENO);
        /*Fin demonio*/

        char id_item[100];
        char articulo[100];
        char producto[100];
        char marca[100];
        char campo[100];
        char valor[100];
        char linea[500];
        char cadena[500]="\0";
        char *aux='\0';
        struct sockaddr_in serv_addr;
        char sendBuff[1025];
        char recevBuff[1025];

        FILE *fp,*fp2;
        fp = fopen( "/tmp/articulos.txt", "r" );
        fp2 = fopen( "/tmp/novedades.txt", "w");


        if(fp == NULL) {printf("File error"); exit(1);}
        else printf("\nArchivo encontrado\n\n");

        memset(sendBuff, '0', sizeof(sendBuff));
        memset(recevBuff, '0', sizeof(recevBuff));
        memset(&serv_addr, '0', sizeof(serv_addr));

        serv_addr.sin_family = AF_INET;
        serv_addr.sin_addr.s_addr = htonl(INADDR_ANY);
        serv_addr.sin_port = htons(7000);

        int listenfd = socket(AF_INET, SOCK_STREAM, 0);
        bind(listenfd, (struct sockaddr*)&serv_addr, sizeof(serv_addr));

        listen(listenfd, 10);
        int connfd = accept(listenfd, (struct sockaddr*)NULL, NULL);
        while(1)
        {
            read(connfd, recevBuff, 100/*strlen((recevBuff)-1)*/);

            //Valor
            aux = strtok(strrchr(recevBuff, '='), "\n");
            strcpy(valor, aux+1);
            *aux = '\0';
            //Campo
            aux = strtok(recevBuff,"=");
            strcpy(campo, aux);
            *aux = '\0';
           // fprintf(fp2,"%s;%s\n",campo, valor);


            while(fgets(linea, sizeof(linea), fp))
            {
                aux = strtok(strrchr(linea, ';'), "\n");
                strcpy(marca, aux+1);
                *aux = '\0';

                aux = strrchr(linea, ';');
                strcpy(producto, aux+1);
                *aux = '\0';

                aux = strrchr(linea, ';');
                strcpy(articulo, aux+1);
                *aux = '\0';

                sscanf(linea, "%10s", id_item);

                if((strcmp(id_item, valor) == 0 && strcmp("ID_ITEM", campo) == 0) ||
                (strcmp(articulo, valor) == 0 && strcmp("ARTICULO", campo) == 0) ||
                (strcmp(producto, valor) == 0 && strcmp("PRODUCTO", campo) == 0) ||
                (strcmp(marca, valor) == 0 && strcmp("MARCA", campo) == 0)){

                    strcat(cadena, id_item);
                    strcat(cadena, ";");
                    strcat(cadena, articulo);
                    strcat(cadena, ";");
                    strcat(cadena, producto);
                    strcat(cadena, ";");
                    strcat(cadena, marca);
                    strcat(cadena, "\n");
                    write(connfd, cadena, 200);
                    fprintf(fp2,"%s\n",cadena);
                    cadena[0]= '\0';
                    }
            }
            fclose(fp2);
        sleep(1);
        }


    }

}
    //close(connfd);
