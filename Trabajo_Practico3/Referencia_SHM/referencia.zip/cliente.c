#define _DEFAULT_SOURCE 1
#include "lib/funciones_ejercicio.c"

    int main(int argc, char const *argv[]){
        //arc tiene 1 = nombre ejecutable
        int n;
        n=argc;
        valida_parametros_minimos(n);
        char ayuda[6];
        strcpy(ayuda,argv[1]);
        valida_ayuda(n,ayuda);
        valida_parametros_invalidos(n);
        char op;
        
        strcpy(nombre_materia,argv[1]);
        mu_rc=abrir_semaforo("mu_rc");
        do{
            system("clear");
            printf("\t\tBIENVENIDO AL SISTEMA CLIENTE DE CARGA DE NOTAS\n\n\t\t\tMATERIA: '%s'\n\n1 - CARGAR NOTAS\n2 - CONSULTAR PROMEDIO DE NOTAS\n3 - AYUDA\n4 - SALIR\n",nombre_materia);
            fflush(stdin);
            printf("\nIngresa tu opcion: \n");
            scanf("%c",&op);
            switch(op){
                case '1':carga_nota(nombre_materia);
                        break;
                case '2':sub_menu_prom();
                        break;
                case '3':muestra_ayuda();
                        break;
                case '4':libera_recursos_abiertos();
            }
        }while(op!='4');
        //}while(!(op=='1'||op=='2'||op=='3'||op=='4'));

        return 0;
    }