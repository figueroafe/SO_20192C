#define _DEFAULT_SOURCE 1
#include "lib/funciones_servidor.c"

///MAIN///

    int main(int argc, char const *argv[]){
        
        //arc tiene 1 = nombre ejecutable
        int n;
        n=argc;
        valida_parametros_minimos(n);

        if(n==2)
            valida_ayuda(n,argv[1]);
        if(n>1){
            printf("El programa no recibe parametros\n");
            printf("Para ver la ayuda del programa, ejecútelo de la siguiente forma:\n");
            printf("./servidor -help:\n");
            exit(2);
        }
        valida_parametros_invalidos(n);
        
    //  L�gica
            shm = (t_procesar *)crear_memoria_compartida("mi_memoria", sizeof(t_procesar));
            cant_lineas=cuenta_lineas_archivo("bd");
  
            mu_rc = crear_semaforo("mu_rc", 1); // MUTEX
            mu_docente_carga_nota = crear_semaforo("mu_docente_carga_nota", 1); // MUTEX
            consulta_prom_por_mat = crear_semaforo("consulta_prom_por_mat", 1); // MUTEX
            consulta_prom_gral = crear_semaforo("consulta_prom_gral", 1); // MUTEX
            hay_msj = crear_semaforo("hay_msj", 0); // CONTADOR
            hay_msj_prom = crear_semaforo("hay_msj_prom", 0); // Mutex rta promedio
            fin_consulta = crear_semaforo("fin_consulta", 0); // Mutex fin de consulta
            
            signal(SIGINT, sigint_handler);
            //pide_ayuda();
            system("clear");
            muestra_menu("\t\tBIENVENIDO AL SISTEMA SERVIDOR DE CARGA DE NOTAS\n\n");
            muestra_menu("\t\t\tEL PROCESO FINALIZA CON: 'ctrl c'\n\n");
            
            while(keep_running){
                sem_wait(hay_msj);//P() 0
                pthread_t hilo_atiendie_cliente;
                int rta=pthread_create(&hilo_atiendie_cliente,NULL,func_thread,NULL);
                if (rta){
                    printf("ERROR in pthread_create(): %d\n", rta);
                    exit(-1);
                }
            }
        return 0;
    }
///FIN DEL MAIN///