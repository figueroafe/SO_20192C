#include <sys/types.h>
#include <stdlib.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <string.h>
#include <dirent.h>
#include <errno.h>
#include <time.h>
#include <ctype.h>
#include <semaphore.h>
///////////////////
//Variables globales
sem_t *mu_rc;
int cant_lineas;
char nombre_materia[BUFSIZ];
///////////////////
typedef struct{
    long int dni;
    char materia[50];
    int nota_1p;
    int nota_2p;
    int nota_rec;
    int promedio_por_materia;
    int promedio_gral;
}t_info;
typedef struct{
    long int dni;
    int promedio_gral;
}t_info2;
typedef struct s_nodo_2{
    t_info2 info2;
    struct s_nodo_2 *psig;
}t_nodo2;
typedef struct s_nodo{
    t_info info;
    struct s_nodo *psig;
}t_nodo;
typedef struct{
  char mensaje[60];
  char mensaje_procesado[60];
  char opcion;
  int cant_lineas;
  char base_de_datos[BUFSIZ];
}t_procesar;

typedef struct{
        long int dni;
        char materia[50];
        char instancia[50];
        int nota;
}t_registro_procesar;
typedef t_nodo *t_lista;//
typedef t_nodo2 *t_lista2;//
typedef int(*t_cmp_lista)(const void *, const void *);//
void saca_promedio_por_materia(t_lista *);//
int insertar_en_orden_lista(t_lista *, const t_registro_procesar *, t_cmp_lista);//
int insertar_en_lista_sin_duplicados(t_lista2 *, const t_info2 *, t_cmp_lista);//
void crear_lista(t_lista *);//
void vaciar_lista(t_lista *);//
void crear_lista2(t_lista2 *);//
void vaciar_lista2(t_lista2 *);//
int lista_llena(t_lista *);//No lo uso pero es primitiva. La dejo
int lista_vacia(const t_lista *);//No lo uso pero es primitiva. La dejo
int comp_dni_materia(const void *,const void *);//
int comp_dni_materia_2(const void *,const void *);
int comp_dni(const void *,const void *);//
int comp_dni_2(const void *,const void *);//
int comp_materia(const void *,const void *);//
t_nodo **buscar_nodo_lista(t_lista *, const t_registro_procesar *, t_cmp_lista );//
t_info buscar_nodo_lista_3(t_lista *, const t_registro_procesar *, t_cmp_lista );
t_nodo2 **buscar_nodo_lista2(t_lista2 *, const t_info2 *, t_cmp_lista);//
void muestra_promedio_por_materia(t_info *);//
void muestra_promedio_gral_2(t_lista *, long int );
void muestra_promedio_gral(t_lista2 *);//
void muestra_titulo(int );//
void saca_promedio_gral(t_lista *,t_lista2 *);//
void saca_promedio_gral_2(t_lista *);
void *valida_ayuda(int , char const *);//
void llena_array_registro(t_registro_procesar *, char *);//
void muestra_ayuda();

int hace_el_prom(int , int , int );
sem_t * abrir_semaforo(const char *);//
void * abrir_memoria_compartida(const char *, size_t );//
void valida_parametros_invalidos(int );//
void valida_parametros_minimos(int );//
void libera_recursos_abiertos();//
void carga_nota(char *);//
void consulta_prom_notas_general();//
void consulta_prom_notas_por_materia();//
void sub_menu_prom();//
void carga_datos(long int *, char *, int *);//
void arma_linea(long int *, char *,char *, int *,char *);//
void muestra_menu(const char *);//

void carga_datos(long int *dni, char *instancia, int *nota){
    char nota_c[10];
    system("clear");
    printf("\t\tPANTALLA CARGA DE NOTAS\n\nMATERIA='%s'\n\n",nombre_materia);
    printf("Ingresa el DNI del alumno: ");
    fflush(stdin);
    
    scanf("%ld",dni);

            char OP;
            muestra_menu("\nEliga la instancia de la evaluacion: \n\n1 - Primero Parcial\n2 - Segundo Parcial\n3 - Recuperatorio\n\n");

            do{
                fflush(stdin);
                scanf("%c",&OP);   
                switch(OP){
                    case '1':strcpy(instancia,"Primero Parcial");break;
                    case '2':strcpy(instancia,"Segundo Parcial");break;
                    case '3':strcpy(instancia,"Recuperatorio");break;
                } 
            }while(!((OP-'0')>=1 && (OP-'0') <=3));//Esto valida opciones enteras entre 1 y 3
    printf("\nIngresa la NOTA: ");
    do{
        fflush(stdin);
        fgets(nota_c,sizeof(nota_c)*10,stdin);    
        }while(!(atoi(nota_c)>=1 && (atoi(nota_c)) <=10));//Esto valida opciones enteras entre 1 y 10
    (*nota)=atoi(nota_c);
}//
void arma_linea(long int *dni, char *nombre_materia,char *instancia, int *nota,char *linea){
    char linea_aux[BUFSIZ];
    sprintf(linea_aux,"%ld",*dni);
    strcpy(linea,"");
    strcat(linea,linea_aux);
    strcat(linea,",");
    strcat(linea,nombre_materia);
    strcat(linea,",");
    strcat(linea,instancia);
    strcat(linea,",");
    sprintf(linea_aux,"%d",*nota);
    strcat(linea,linea_aux);
    strcat(linea,"\n");
}//
void muestra_menu(const char *msg){
    printf("%s",msg);
}//
void muestra_ayuda(){
    system("clear");
    muestra_menu("****************************************************************************\nPrograma CLIENTE que permite la carga de datos a docentes de materias \nvia memoria compartida.\nDebe recibir como único parámetro, el nombre de la materia a cual\npertenece el docente.\nPara correr el programa, ejecutelo de la siguiente forma:\n\t\tPor ejemplo: ./cliente 'Sistemas Operativos'\n****************************************************************************\n");
    sleep(5);
}
void *valida_ayuda(int n, char const *ayuda){
    if(n>2 && (strcmp(ayuda,"-help")==0)){
        muestra_menu("Para ver una ayuda escriba: \n./cliente -help\n");
        exit(9);
    }
    
    if((n==2) && (strcmp(ayuda,"-help")==0)){
        muestra_menu("****************************************************************************\nPrograma CLIENTE que permite la carga de datos a docentes de materias \nvia memoria compartida.\nDebe recibir como único parámetro, el nombre de la mteria a cual\npertenece el docente.\nPara correr el programa, ejecutelo de la siguiente forma:\n\t\tPor ejemplo: ./cliente 'Sistemas Operativos'\n****************************************************************************\n");
        exit(7);    
    }
    return EXIT_SUCCESS;
}//
void sub_menu_prom(){
    char op;
    do{
            system("clear");
            muestra_menu("\t\tSUB-MENU CONSULTA PROMEDIO DE NOTAS\n\n2 - PROMEDIO POR MATERIA\n3 - PROMEDIO GENERAL\n0 - VOLVER\n");
            fflush(stdin);
            printf("\nIngresa tu opcion: \n");
            scanf("%c",&op);
            switch(op){
                case '2':consulta_prom_notas_por_materia();break;
                case '3':consulta_prom_notas_general();break;
                case '0':break;
            }
        }while(op!='0');
}//
void consulta_prom_notas_general(){//OPCION 3 del SERVIDOR
    //sem_t *mu_rc=abrir_semaforo("mu_rc");
    int valor;
    char msg[100];
    sem_getvalue(mu_rc, &valor);
    valor==0?strcpy(msg,"Aguarde un instante por favor. Hay otra transacción en curso. .. ...\n"):strcpy(msg,"Procesando . .. ...\n");
    printf("%s",msg);
    sem_wait(mu_rc);

    sem_t *consulta_prom_gral = abrir_semaforo("consulta_prom_gral");
    int value;
    char mensaje[100];
    sem_getvalue(consulta_prom_gral, &value);
    value==0?strcpy(mensaje,"Aguarde un instante por favor. Hay otro docente consultando un promedio general . .. ...\n"):strcpy(mensaje,"Procesando . .. ...\n");
    printf("%s",mensaje);
    sem_wait(consulta_prom_gral);
    system("clear");
    printf("\t\tPANTALLA CONSULTA PROMEDIO DE NOTAS POR MATERIA GRAL\n\nMATERIA='%s'\n\n",nombre_materia);
    t_procesar procesar;
    procesar.opcion='3';
    
    t_procesar *shm = (t_procesar *)abrir_memoria_compartida("mi_memoria", sizeof(t_procesar));
    sem_t *hay_msj = abrir_semaforo("hay_msj");
    sem_t *hay_msj_prom= abrir_semaforo("hay_msj_prom");
	//sem_t *mu_rc = abrir_semaforo("mu_rc");
    
    //sem_wait(mu_rc);//P() 1 ->0
    shm->opcion=procesar.opcion;
    //sem_post(mu_rc); //V() ->1
    sem_post(hay_msj);//V() entra el cliente al servidor
    
    sem_wait(hay_msj_prom);

    char aux[BUFSIZ];
    //sem_wait(mu_rc);//P() 1 ->0
    cant_lineas=shm->cant_lineas;
    strcpy(aux,shm->base_de_datos);
    //sem_post(mu_rc); //V() ->1

    t_registro_procesar *p=(t_registro_procesar*)malloc(sizeof(t_registro_procesar)*cant_lineas);
    if (p == 0){
            printf("ERROR: Out of memory(shm_prom)\n");
            exit(1);
    }
    llena_array_registro(p,aux);
    
    t_lista lista;
    crear_lista(&lista);
    int i;
    for(i=0;i<cant_lineas;i++){
        insertar_en_orden_lista(&lista,(p+i),comp_dni_materia_2);
    }   
    saca_promedio_por_materia(&lista);
    long int dni;
    printf("\nIngresa el DNI del alumno: ");
    fflush(stdin);
    scanf("%ld",&dni);
    system("clear");
    muestra_promedio_gral_2(&lista,dni);
    //t_lista2 lista2;
    //crear_lista2(&lista2);
    
    //saca_promedio_gral(&lista,&lista2);
    //muestra_promedio_gral(&lista2);
    sleep(5);
    vaciar_lista(&lista);
    //vaciar_lista2(&lista2);
    free(p);
    sem_post(consulta_prom_gral);
    sem_post(mu_rc);
    sem_t *fin_consulta= abrir_semaforo("fin_consulta");
    sem_post(fin_consulta);
}//
void llena_array_registro(t_registro_procesar *r, char *s){
    //s es la BD
    char aux[BUFSIZ];
   
    
    r->nota=0;
    int k;
    for(k=0;k<cant_lineas;k++){
        int i=0;
        while(*s!='\n'){
            char aux[70];
            int j=0;
            while(*s!=','){
                if(*s=='\n')
                    break;
                char caracter=*s;
                //char aux2[1]={caracter};
                aux[j]=caracter;
                //printf("%s",aux2);
                s++;
                j++;
            }
            if(*s!='\n')
                s++;//esto corre el puntero despues de la coma
            aux[j]='\0';
            //36200355,Sistemas Operativos,Primero Parcial,7\n
            switch (i){
                case 0:
                    r->dni=(long)atoi(aux);
                    break;
                case 1:
                    strcpy(r->materia,aux);
                    break;
                case 2:
                    strcpy(r->instancia,aux);
                    break;
                case 3:
                    r->nota=atoi(aux);
                    break;
                default:
                    break;
            }
            i++;
        }
        s++;
        r++;
    }
}//
void consulta_prom_notas_por_materia(){//OPCION 2 del SERVIDOR
    //sem_t *mu_rc=abrir_semaforo("mu_rc");
    //mu_rc=abrir_semaforo("mu_rc");
    int valor;
    char msg[100];
    sem_getvalue(mu_rc, &valor);
    valor==0?strcpy(msg,"Aguarde un instante por favor. Hay otra transacción en curso. .. ...\n"):strcpy(msg,"Procesando . .. ...\n");
    printf("%s",msg);
    sem_wait(mu_rc);


    sem_t *consulta_prom_por_mat = abrir_semaforo("consulta_prom_por_mat");
     int value;
    char mensaje[100];
    sem_getvalue(consulta_prom_por_mat, &value);
    value==0?strcpy(mensaje,"Aguarde un instante por favor. Hay otro docente consultando un promedio por materia . .. ...\n"):strcpy(mensaje,"Procesando . .. ...\n");
    printf("%s",mensaje);
    sem_wait(consulta_prom_por_mat);
    system("clear");
    printf("\t\tPANTALLA CONSULTA PROMEDIO DE NOTAS POR MATERIA\n\nMATERIA='%s'\n\n",nombre_materia);
    t_procesar procesar;
    procesar.opcion='2';
    
    t_procesar *shm = (t_procesar *)abrir_memoria_compartida("mi_memoria", sizeof(t_procesar));
    sem_t *hay_msj = abrir_semaforo("hay_msj");
    sem_t *hay_msj_prom= abrir_semaforo("hay_msj_prom");
	//sem_t *mu_rc = abrir_semaforo("mu_rc");
    
    //sem_wait(mu_rc);//P() 1 ->0
    shm->opcion=procesar.opcion;
    //sem_post(mu_rc); //V() ->1
    sem_post(hay_msj);//V() entra el client al servidor
    
    sem_wait(hay_msj_prom);

    char aux[BUFSIZ];
    //sem_wait(mu_rc);//P() 1 ->0
    cant_lineas=shm->cant_lineas;
    strcpy(aux,shm->base_de_datos);
    //sem_post(mu_rc); //V() ->1

    t_registro_procesar *p=(t_registro_procesar*)malloc(sizeof(t_registro_procesar)*cant_lineas);
    if (p == 0){
            printf("ERROR: Out of memory(shm_prom)\n");
            exit(1);
    }
    llena_array_registro(p,aux);
   
    t_lista lista;
    crear_lista(&lista);
    int i;
    for(i=0;i<cant_lineas;i++){
        insertar_en_orden_lista(&lista,(p+i),comp_dni_materia_2);
    } 
   
    saca_promedio_por_materia(&lista);
  
    t_registro_procesar info_aux;
    long int dni;
    printf("\nIngresa el DNI del alumno: ");
    fflush(stdin);
    scanf("%ld",&dni);
    info_aux.dni=dni;
    strcpy(info_aux.materia,nombre_materia);
    
    t_info info=buscar_nodo_lista_3(&lista,&info_aux,comp_dni_materia_2);
    system("clear");
    if(info.dni==0)
        printf("El alumno '%ld' no se encontró en la BD\n",dni);
    else
        muestra_promedio_por_materia(&info);
    
    //muestra_promedio_por_materia(&lista);
    vaciar_lista(&lista);
    free(p);
    sleep(5);
    sem_post(consulta_prom_por_mat);
    sem_post(mu_rc);
    sem_t *fin_consulta= abrir_semaforo("fin_consulta");
    sem_post(fin_consulta);
}//
void valida_parametros_minimos(int n){
         if(n == 1){
            printf("Faltan parámetros MINIMOS. Para ver una ayuda, corra el programa con:\n>./cliente -help\n");
            exit(2);
        }
}//
void valida_parametros_invalidos(int n){
        if(n > 2){
            printf("Cantidad de parámetros inválidos. Para ver una ayuda, corra el programa con:\n>./cliente -help\n");
            exit(1);
        }
}//
void carga_nota(char *nombre_materia){//OPCION 1 DEL SERVIDOR
    //sem_t *mu_rc=abrir_semaforo("mu_rc");
    int valor;
    char msg[100];
    sem_getvalue(mu_rc, &valor);
    valor==0?strcpy(msg,"Aguarde un instante por favor. Hay otra transacción en curso. .. ...\n"):strcpy(msg,"Procesando . .. ...\n");
    printf("%s",msg);
    sem_wait(mu_rc);


    sem_t *mu_docente_carga_nota = abrir_semaforo("mu_docente_carga_nota");
    int value;
    char mensaje[100];
    sem_getvalue(mu_docente_carga_nota, &value);
    value==0?strcpy(mensaje,"Aguarde un instante por favor. Hay otro docente cargando una nota. .. ...\n"):strcpy(mensaje,"Procesando . .. ...\n");
    printf("%s",mensaje);
    sem_wait(mu_docente_carga_nota);
    system("clear");
    long int dni;
    char materia[26];
    char evaluacion[26];
    int nota;
    char linea[BUFSIZ];
    t_procesar procesar;
    
    strcpy(materia,nombre_materia);
    carga_datos(&dni,evaluacion,&nota);
    arma_linea(&dni,materia,evaluacion,&nota,linea);
    system("clear");

    procesar.opcion='1';
    strcpy(procesar.mensaje,linea);

    t_procesar *shm = (t_procesar *)abrir_memoria_compartida("mi_memoria", sizeof(t_procesar));

	sem_t *hay_msj = abrir_semaforo("hay_msj");
    //sem_t *mu_rc = abrir_semaforo("mu_rc");
    
    
    //sem_wait(mu_rc);//P() 1 ->0
    strcpy(shm->mensaje,procesar.mensaje);
    shm->opcion=procesar.opcion;
    sem_post(mu_rc);// V()
    sem_post(mu_docente_carga_nota);
    //Hay un nuevo mensaje en la BD
    sem_post(hay_msj);//V()
}//
void libera_recursos_abiertos(){
    system("clear");

    exit(0);
}//
sem_t * abrir_semaforo(const char *nombre){
	sem_t *aux;
    aux=sem_open(nombre, 0);
    if(aux==SEM_FAILED){
        printf("El semaforo debe primero ser creada\n"); 
        printf("Debe correr primero el servidor\n");
        exit(EXIT_FAILURE);
    }
    return aux;
}//
void * abrir_memoria_compartida(const char *nombre, size_t size){
	int fd = shm_open(nombre, O_RDWR, 0);
    if(fd==-1){
        printf("La Memoria compartida debe primero ser creada\n"); 
        printf("Debe correr primero el servidor\n");
        exit(EXIT_FAILURE);
    }
	ftruncate(fd, sizeof(60)); // Setea el tamaño de la memoria

	void *dir = mmap(NULL, size, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
	return dir;
}//
void muestra_promedio_gral(t_lista2 *plista){
    muestra_titulo(0);
    while(*plista){
        printf("%ld\t\t%d\n",(*plista)->info2.dni,(*plista)->info2.promedio_gral);
        plista=&(*plista)->psig;
    }
}//
void muestra_titulo(int n){
    char promedio[50];
    n==1?strcpy(promedio,"Materia\t\t\t\tPromedio_por_Materia"):strcpy(promedio,"\tPromedio_Gral");
    printf("DNI\t\t%s\n",promedio);
}//
void muestra_promedio_por_materia(t_info *pinfo){
    muestra_titulo(1);
    printf("\n%ld\t%s\t\t%d\n",pinfo->dni,pinfo->materia,pinfo->promedio_por_materia);
    /*
    while(*plista){
        printf("%ld\t%s\t\t%d\n",(*plista)->info.dni,(*plista)->info.materia,(*plista)->info.promedio_por_materia);
        plista=&(*plista)->psig;
    }*/
}//
void muestra_promedio_gral_2(t_lista *plista, long int dni){
    muestra_titulo(1);
    //printf("\n%ld\t%s\t\t%d\n",pinfo->dni,pinfo->materia,pinfo->promedio_por_materia);
    
    while(*plista){
        if(dni==(*plista)->info.dni)
            printf("%ld\t%s\t\t%d\n",(*plista)->info.dni,(*plista)->info.materia,(*plista)->info.promedio_por_materia);
        plista=&(*plista)->psig;
    }
}
void saca_promedio_por_materia(t_lista *plista){
    while(*plista){
    
        int nota_1_p=(*plista)->info.nota_1p;
        int nota_2_p=(*plista)->info.nota_2p;
        int nota_rec=(*plista)->info.nota_rec;
        int aux=hace_el_prom(nota_1_p,nota_2_p,nota_rec);
        
        //aux=( (*plista)->info.nota_1p + (*plista)->info.nota_2p + (*plista)->info.nota_rec) / 3;
        (*plista)->info.promedio_por_materia=aux;
        plista=&(*plista)->psig;
    }
}//
int hace_el_prom(int nota_1_p, int nota_2_p, int nota_rec){
    // 7 2 10
        int aux=0;
        if(nota_1_p>=4 && nota_2_p>=4){
            aux=(nota_1_p+nota_2_p)/2;  
        }
        if(nota_1_p>=4 && nota_rec>=4){
            aux=(nota_1_p+nota_rec)/2;  
        }
        if(nota_2_p>=4 && nota_rec>=4){
            aux=(nota_2_p+nota_rec)/2;  
        }
        if(nota_1_p<=4 && nota_2_p<=4){
            aux=(nota_1_p+nota_2_p)/2;  
        }
        if(nota_1_p<4 && nota_2_p>=4 && nota_rec>=4){
            aux=(nota_2_p+nota_rec)/2;  
        }
        if(nota_1_p<=4 && nota_2_p>=4 && nota_rec==0|| nota_2_p<=4 && nota_1_p>=4 && nota_rec==0){
            aux=(nota_1_p+nota_2_p)/2;  
        }
        if(nota_1_p>=4 && nota_2_p==0 && nota_rec==0){
            aux=nota_1_p;  
        }
        if(nota_2_p>=4 && nota_1_p==0 && nota_rec==0){
            aux=nota_2_p;  
        }
        if(nota_2_p==0 && nota_1_p==0 && nota_rec>=4){
            aux=nota_rec;
        }
        return aux;
}
void saca_promedio_gral_2(t_lista *plista){
    
    while(*plista){
        int prom_gral=0;
        int cant_materias=1;
        t_lista *paux=&(*plista)->psig;
        while(*paux){
            if((*plista)->info.dni== (*paux)->info.dni){
                prom_gral+=(*plista)->info.promedio_por_materia+(*paux)->info.promedio_por_materia;
                cant_materias++;
            }
            paux=&(*paux)->psig;
        }
        t_info2 info2;
        info2.dni=(*plista)->info.dni;
        info2.promedio_gral=cant_materias==1?(*plista)->info.promedio_por_materia:(prom_gral/cant_materias);
        plista=&(*plista)->psig;
    }
}//
void saca_promedio_gral(t_lista *plista,t_lista2 *plista2){
    
    while(*plista){
        int prom_gral=0;
        int cant_materias=1;
        t_lista *paux=&(*plista)->psig;
        while(*paux){
            if((*plista)->info.dni== (*paux)->info.dni){
                prom_gral+=(*plista)->info.promedio_por_materia+(*paux)->info.promedio_por_materia;
                cant_materias++;
            }
            paux=&(*paux)->psig;
        }
        t_info2 info2;
        info2.dni=(*plista)->info.dni;
        info2.promedio_gral=cant_materias==1?(*plista)->info.promedio_por_materia:(prom_gral/cant_materias);
        insertar_en_lista_sin_duplicados(plista2,&info2,comp_dni_2);
        plista=&(*plista)->psig;
    }
}//
//Funciones de Lista
void vaciar_lista(t_lista *plista){
    t_nodo *pelim;

    while (*plista){
        pelim = *plista;
        *plista = pelim->psig;
        free(pelim);
    }
}//
void vaciar_lista2(t_lista2 *plista){
    t_nodo2 *pelim;

    while (*plista){
        pelim = *plista;
        *plista = pelim->psig;
        free(pelim);
    }
}//
void crear_lista(t_lista *p){
    *p=NULL;
}//
void crear_lista2(t_lista2 *p){
    *p=NULL;
}//
int lista_llena(t_lista *p){
    t_nodo *pelim=(t_nodo*)malloc(sizeof(t_nodo));
    free(pelim);
    return pelim==NULL;
}//No lo uso pero es primitiva. La dejo
int lista_vacia(const t_lista *p){
    return p==NULL;
}//No lo uso pero es primitiva. La dejo
int comp_dni_materia(const void *v1,const void *v2){
    t_registro_procesar *i1=(t_registro_procesar*)v1;
    t_info *i2=(t_info*)v2;
    return i1->dni-i2->dni && strcmp(i1->materia,i2->materia)==0;
}//
int comp_dni_materia_2(const void *v1,const void *v2){
    t_registro_procesar *i1=(t_registro_procesar*)v1;
    t_info *i2=(t_info*)v2;
    int resta_DNI=i1->dni-i2->dni;
    int resta_MATERIA=strcmp(i1->materia,i2->materia);
    return (resta_DNI==resta_MATERIA)&&(resta_DNI==0&&resta_MATERIA==0)?0:1;
}//
int comp_dni(const void *v1,const void *v2){
    t_registro_procesar *i1=(t_registro_procesar*)v1;
    t_info *i2=(t_info*)v2;
    return i1->dni-i2->dni;
}//
int comp_dni_2(const void *v1,const void *v2){
    t_info2 *i1=(t_info2*)v1;
    t_info2 *i2=(t_info2*)v2;
    return i1->dni-i2->dni;
}//
int comp_materia(const void *v1,const void *v2){
    t_registro_procesar *i1=(t_registro_procesar*)v1;
    t_info *i2=(t_info*)v2;
    return strcmp(i1->materia,i2->materia);
}//
int insertar_en_orden_lista(t_lista *plista, const t_registro_procesar *pregistro, t_cmp_lista comp_dni_materia_2){
    t_nodo *pnue;
    int res_comp;
    pnue=(t_nodo*)malloc(sizeof(t_nodo));
    if(!pnue)
        return 3;//LISTA_LLENA
    plista=buscar_nodo_lista(plista,pregistro,comp_dni_materia_2);
    while( (*plista) && (res_comp=comp_dni(pregistro,&(*plista)->info))>0)
        plista=&(*plista)->psig;
    if( (*plista) && (res_comp=comp_materia(pregistro,&(*plista)->info))==0 ){
        
        if(strcmp(pregistro->instancia,"Primero Parcial")==0)
            (*plista)->info.nota_1p=pregistro->nota;
        if(strcmp(pregistro->instancia,"Segundo Parcial")==0)
            (*plista)->info.nota_2p=pregistro->nota;
        if(strcmp(pregistro->instancia,"Recuperatorio")==0)
            (*plista)->info.nota_rec=pregistro->nota;
    return 2;//DUPLICADO
    }
    
    pnue->info.dni=pregistro->dni;
    strcpy(pnue->info.materia,pregistro->materia);

    pnue->info.nota_1p=0;
    pnue->info.nota_2p=0;
    pnue->info.nota_rec=0;

    if(strcmp(pregistro->instancia,"Primero Parcial")==0)
        pnue->info.nota_1p=pregistro->nota;
    if(strcmp(pregistro->instancia,"Segundo Parcial")==0)
        pnue->info.nota_2p=pregistro->nota;
    if(strcmp(pregistro->instancia,"Recuperatorio")==0)
        pnue->info.nota_rec=pregistro->nota;

    pnue->psig=(*plista);
    (*plista)=pnue;
    return 0;//TODO_OK
}//
t_nodo **buscar_nodo_lista(t_lista *plista, const t_registro_procesar *pregistro, t_cmp_lista comp_dni_materia_2){
//    while( (*plista) && comp_dni_materia(pregistro,&(*plista)->info)!=0)
    while( (*plista) && comp_dni_materia_2(pregistro,&(*plista)->info)!=0)
        plista=&(*plista)->psig;
    return plista;
}//
t_info buscar_nodo_lista_3(t_lista *plista, const t_registro_procesar *pregistro, t_cmp_lista comp_dni_materia_2){
    int res_comp;
    //plista=buscar_nodo_lista(plista,pregistro,comp_dni_materia);
    while( (*plista) && (res_comp=comp_dni_materia_2(pregistro,&(*plista)->info))>0)
        plista=&(*plista)->psig;
    if( (*plista) && (res_comp=comp_dni_materia_2(pregistro,&(*plista)->info))==0 )
        return (*plista)->info;
    t_info aux;
    aux.dni=0;
    return aux;
}//
t_nodo2 **buscar_nodo_lista2(t_lista2 *plista, const t_info2 *pregistro, t_cmp_lista comp_dni_2){
    while( (*plista) && comp_dni_2(pregistro,&(*plista)->info2)!=0)
        plista=&(*plista)->psig;
    return plista;
}//
int insertar_en_lista_sin_duplicados(t_lista2 *plista, const t_info2 *pinfo2, t_cmp_lista comp_dni_2){
    t_nodo2 *pnue;
    int res_comp;
    pnue=(t_nodo2*)malloc(sizeof(t_nodo2));
    if(!pnue)
        return 3;//LISTA_LLENA
    plista=buscar_nodo_lista2(plista,pinfo2,comp_dni_2);
    while( (*plista) && (res_comp=comp_dni_2(pinfo2,&(*plista)->info2))>0)
        plista=&(*plista)->psig;
    if( (*plista) && (res_comp=comp_dni_2(pinfo2,&(*plista)->info2))==0 )
        return 2;//DUPLICADO

    pnue->info2=*pinfo2;
    pnue->psig=(*plista);
    (*plista)=pnue;
    return 0;//TODO_OK
}//
