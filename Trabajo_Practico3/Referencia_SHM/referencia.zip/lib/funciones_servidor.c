#define _POSIX_C_SOURCE 199309L
#define _SVID_SOURCE
#include <sys/types.h>
#include <stdlib.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>
#include <pthread.h>
#include <string.h>
#include <dirent.h>
#include <errno.h>
#include <time.h>
#include <ctype.h>
#include <semaphore.h>
#include <sys/wait.h>
#include <sys/time.h>
#include <sys/resource.h>
#include <wait.h>
#include <assert.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <signal.h>

typedef struct{
  char mensaje[60];
  char mensaje_procesado[60];
  char opcion;
  int cant_lineas;
  char base_de_datos[BUFSIZ];
}t_procesar;//Lo uso para depositar el mensaje a procesar en la SH_MEM y para dejar la BD para que el cliente la procese.

//INICIO Variables globales
static volatile int keep_running = 1;
int cant_lineas;//
sem_t *mu_rc;//
sem_t *mu_docente_carga_nota;
sem_t *consulta_prom_por_mat;
sem_t *consulta_prom_gral;
sem_t *hay_msj;//
sem_t *hay_msj_prom;//
sem_t *fin_consulta;//
t_procesar *shm;//
//FIN variables globales

void pide_ayuda();
void inserta_registro_en_bd(const char *);//
void copiar_bd(char *, char *);//
sem_t *crear_semaforo(const char *nombre, int valor);//
void borrar_semaforo(const char * nombre, sem_t *semaforo);//
void * crear_memoria_compartida(const char *nombre, size_t size);//
void borrar_memoria_compartida(const char *nombre, size_t size, void *direccion);//
void *valida_ayuda(int n, char const *);//
int cuenta_lineas_archivo(char *);//
void *func_thread(void *);//
void saca_hora_minuto(char *, char *);//
char * get_current_time();//
void valida_parametros_invalidos(int );//
void valida_parametros_minimos(int );//
void libera_recursos_abiertos();//
void muestra_menu(const char *);//
void sigint_handler(int );//
int corta_cadena(char *, char *, char *, const char );//
char** str_split(char* , const char );//

void sigint_handler(int dummy) {
    keep_running = 0;
    libera_recursos_abiertos();
}//
void pide_ayuda(){
    char op;
    printf("¿Queres ver una ayuda? S/N: ");
    fflush(stdin);
    scanf("%c",&op);
    if(op=='s'||op=='S'){
        system("clear");
        muestra_menu("****************************************************************************\nPrograma SERVIDOR que permite la carga de datos a docentes de materias \nvia memoria compartida.\nEste programa NO RECIBE PARÁMETROS.\nPara correr el programa, ejecutelo de la siguiente forma:\n\t\tPor ejemplo: ./servidor\n****************************************************************************\n");
        sleep(5);
    }
    if(op=='n'||op=='N'){
        return;
    }
}
void muestra_menu(const char *msg){
    printf("%s",msg);
}//
void *valida_ayuda(int n, char const *ayuda){
    if(n>2 && (strcmp(ayuda,"-help")==0)){
        printf("Para ver una ayuda escriba: \n");
        printf("./cliente -help\n");
        exit(9);
    }
    
    if((n==2) && (strcmp(ayuda,"-help")==0)){
        printf("****************************************************************************\n");
        printf("Programa SERVIDOR que permite atender las peticiones de la carga de datos que hacen docentes de sus materias \n");
        printf("via memoria compartida.\n"); 
        printf("El programa no recibe parametros\n"); 
        printf("Para correr el programa, ejecutelo de la siguiente forma:\n");
        printf("\t\tPor ejemplo: ./servidor\n");
        printf("Si desea ver una ayuda, ejecute el programa de la siguiente forma:\n");
        printf("\t\tPor ejemplo: ./servidor -help\n");
        printf("****************************************************************************\n");
        exit(7);    
    }
    return EXIT_SUCCESS;
}//
void valida_parametros_minimos(int n){
         if(n < 1){
            printf("Faltan parámetros MINIMOS.\n");
            exit(2);
        }
}//
void valida_parametros_invalidos(int n){
        if(n > 2){
            printf("Cantidad de parámetros inválidos.\n");
            exit(1);
        }
}//
void libera_recursos_abiertos(){
    system("clear");
    borrar_memoria_compartida("mi_memoria", sizeof(t_procesar), shm);
    
    borrar_semaforo("fin_consulta",fin_consulta);
    borrar_semaforo("mu_rc", mu_rc);
    borrar_semaforo("hay_msj", hay_msj);
    borrar_semaforo("hay_msj_prom", hay_msj_prom);
    borrar_semaforo("mu_docente_carga_nota", mu_docente_carga_nota);
    borrar_semaforo("consulta_prom_por_mat", consulta_prom_por_mat);
    borrar_semaforo("consulta_prom_gral", consulta_prom_gral);
    printf("\nAntes de cerrar, se liberan todos los recursos abiertos(Semáforos y Memoria Compartida)\n\n");
    exit(0);
}//
char *get_current_time(){
    time_t rawtime;
    struct tm * timeinfo;

    time ( &rawtime );
    timeinfo = localtime ( &rawtime );
    //printf ( "Current local time and date: %s", asctime (timeinfo) );
    return asctime(timeinfo);
}//
char** str_split(char* a_str, const char a_delim){
    char** result    = 0;
    size_t count     = 0;
    char* tmp        = a_str;
    char* last_comma = 0;
    char delim[2];
    delim[0] = a_delim;
    delim[1] = 0;

    /* Count how many elements will be extracted. */
    while (*tmp)
    {
        if (a_delim == *tmp)
        {
            count++;
            last_comma = tmp;
        }
        tmp++;
    }

    /* Add space for trailing token. */
    count += last_comma < (a_str + strlen(a_str) - 1);

    /* Add space for terminating null string so caller
       knows where the list of returned strings ends. */
    count++;

    result = malloc(sizeof(char*) * count);

    if (result)
    {
        size_t idx  = 0;
        char* token = strtok(a_str, delim);

        while (token)
        {
            assert(idx < count);
            *(result + idx++) = strdup(token);
            token = strtok(0, delim);
        }
        assert(idx == count - 1);
        *(result + idx) = 0;
    }

    return result;
}//
int corta_cadena(char *str, char *left_str, char *right_str, const char delimiter){
    char** tokens;
    tokens = str_split(str,delimiter);
    
    if (tokens){
        int i;
        for (i = 0; *(tokens + i); i++){
            if(i==0)
                strcpy(left_str,*(tokens+i));
            if(i==1)
                strcpy(right_str,*(tokens+i));
            free(*(tokens + i));
        }
        free(tokens);
        return EXIT_SUCCESS;
    }
    return EXIT_FAILURE;
}//
void saca_hora_minuto(char *hora, char *minutos){
    char aux[25];
    char izq[28];
    
    strcpy(aux,get_current_time());
    corta_cadena(aux,izq,minutos,':');
    char aux2[4];// 17 // aux2[1];aux2[2]
    strcpy(aux2,strrchr(izq,' '));
    char hora_aux[3]={aux2[1],aux2[2]};
    strcpy(hora,hora_aux);
}//
sem_t * crear_semaforo(const char *nombre, int valor){
	return sem_open(nombre, O_CREAT, S_IRUSR | S_IWUSR, valor); // 0600
}//
void borrar_semaforo(const char * nombre, sem_t *semaforo){
	sem_close(semaforo);
	sem_unlink(nombre);
}//
void * crear_memoria_compartida(const char *nombre, size_t size){
	int fd = shm_open(nombre, O_CREAT | O_RDWR, S_IRUSR | S_IWUSR); // O_EXCL
	ftruncate(fd, size); // Setea el tamaño de la memoria

	void *dir = mmap(NULL, size, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
	return dir;
}//
void borrar_memoria_compartida(const char *nombre, size_t size, void *direccion){
	munmap(direccion, size);
	shm_unlink(nombre);
}//
void copiar_bd(char *path, char *linea){
    FILE *pf=fopen(path,"r");
    if(pf==NULL){
        printf("Error con la BD. Verifique su existencia");
        exit(1);
    }
    char aux[100];
    while(fgets(aux,sizeof(char)*100,pf))
        strcat(linea,aux);
    fclose(pf);
}//
void inserta_registro_en_bd(const char *registro){
    
    FILE *pf=fopen("bd","a");
        if(pf==NULL){
            printf("Error al leer el archivo 'bd'. Verifique el archivo.\n");
            exit(1);
        }
        fprintf(pf,"%s",registro);
        fclose(pf);
}//
void *func_thread(void *args){
    
    char aux[60];
    char aux_opcion;

    //37111325,'Programacion Avanzada','Recuperatorio',10
    //sem_wait(mu_rc);
    aux_opcion=shm->opcion;
    //sem_post(mu_rc);
    cant_lineas=cuenta_lineas_archivo("bd");
    if(aux_opcion=='1'){ //Carga Nota    
        //sem_wait(mu_rc);
        strcpy(aux,shm->mensaje);
        //sem_post(mu_rc);
        inserta_registro_en_bd(aux);
        //Mensaje de log en el servidor
        
        char minutos[3];
        char hora[3];
        saca_hora_minuto(hora,minutos);
        printf("\t\t%s:%s - Se insertó un nuevo registro en la BD.\n",hora,minutos);        
    }
    if(aux_opcion=='2'||aux_opcion=='3'){ //Promedio por materia
        
        char linea[BUFSIZ];
        //Aca tiro la BD asi en crudo
        copiar_bd("bd",linea);
        
        //sem_wait(mu_rc);//P() 1 ->0
        shm->cant_lineas=cant_lineas;
        strcpy(shm->base_de_datos,linea);
        //sem_post(mu_rc); //V() 0->1
        char minutos[3];
        char hora[3];
        saca_hora_minuto(hora,minutos);

        
        sem_post(hay_msj_prom);// V() Aviso al cliente que ya tiene la BD para procesar lo que necesita
        sem_wait(fin_consulta);//P() 0->1
        aux_opcion=='2'?printf("\t\t%s:%s - Se realizó una consulta de promedio por materia en la BD.\n",hora,minutos):printf("\t\t%s:%s - Se realizó una consulta de promedio gral en la BD.\n",hora,minutos);  
        }
}//
int cuenta_lineas_archivo(char *path){
    FILE *pf=fopen(path,"r");
    if(pf==NULL){
        printf("(1) Error con el archivo de Base de Datos. Verifique que exista y corra nuevamente el programa\n");
        exit(1);
    }
    char aux[100];
    int cant_lineas=0;
    while(fgets(aux,sizeof(aux),pf)){
        cant_lineas++;
    }
    fclose(pf);
    return cant_lineas;
}//
