#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>
#include <signal.h>
#include <sys/wait.h>

void crearHijo();
int crearNieto();
int crearDemonio();
int crearZombie();
pid_t pid, pid2;

int main(){
    pid = fork();
    pid2 = fork();
    if(pid == 0 || pid2 == 0)
    printf ("PID: %d PPID: %d Parentesco-Tipo: [hijo/nieto]-[normal/demonio/zombie]\n", getpid(), getppid());
    else
    printf ("PID: %d PPID: %d\n", getpid(), getppid());
}

void crearHijo()
{

}
