#ifndef OBJETO_H_INCLUDED
#define OBJETO_H_INCLUDED

class objeto{

private:
int dato;
float otro;

}

#endif // OBJETO_H_INCLUDED
