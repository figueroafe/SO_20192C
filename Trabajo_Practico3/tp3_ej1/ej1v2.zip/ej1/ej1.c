#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>
#include <signal.h>
#include <sys/wait.h>

int crearHijo();
int crearNieto();
int crearDemonio();
int crearZombie();
pid_t pid, pid2, pid3, pid4, pid5, pid6, pid7, pid8, pid9, pid10;

int main(){
    pid = fork();
    if(pid == 0){
        printf ("PID: %d PPID: %d Parentesco-Tipo: [hijo] - [normal]\n", getpid(), getppid());
        pid5 = fork();
        if(pid5 == 0){
            printf ("PID: %d PPID: %d Parentesco-Tipo: [nieto] - [normal]\n", getpid(), getppid());
            pid9 = fork();
            if(pid9 == 0)
                printf ("PID: %d PPID: %d Parentesco-Tipo: [bisnieto] - [zombie]\n", getpid(), getppid());
            else{
                pid10 = fork();
            if(pid10 == 0)
                printf ("PID: %d PPID: %d Parentesco-Tipo: [bisnieto] - [zombie]\n", getpid(), getppid());
            else
                sleep(60);
            }
        }
        else{
            pid6 = fork();
            if(pid6 == 0){
                printf ("PID: %d PPID: %d Parentesco-Tipo: [nieto] - [normal]\n", getpid(), getppid());
                pid7 = fork();
                if(pid7 == 0)
                    printf ("PID: %d PPID: %d Parentesco-Tipo: [bisnieto] - [normal]\n", getpid(), getppid());
                else{
                    pid8 = fork();
                    if(pid8 == 0)
                        printf ("PID: %d PPID: %d Parentesco-Tipo: [bisnieto] - [normal]\n", getpid(), getppid());
                }
            }
        }
    }
    else{
        printf ("PID: %d PPID: %d Parentesco-Tipo: [padre] - [normal]\n", getpid(), getppid());
        pid2 = fork();
        if(pid2 == 0){
            printf ("PID: %d PPID: %d Parentesco-Tipo: [hijo] - [normal]\n", getpid(), getppid());
            pid3 = fork();
            if(pid3 == 0){
                printf ("PID: %d PPID: %d Parentesco-Tipo: [nieto] - [normal]\n", getpid(), getppid());
                pid4 = fork();
                if(pid4 == 0)
                    printf ("PID: %d PPID: %d Parentesco-Tipo: [bisnieto] - [normal]\n", getpid(), getppid());
            }
        }
    }
    //getchar();
    //https://www.busindre.com/crear_matar_y_entender_los_procesos_zombie
}
