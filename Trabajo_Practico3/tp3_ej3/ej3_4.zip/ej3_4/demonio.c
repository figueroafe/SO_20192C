#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include <stdio.h>
#include <string.h>

struct archivocsv
  {
      char id_item[100];
      char articulo[100];
      char producto[100];
      char marca[100];
  } campoarchivo, consulta;


int main(void)
{
    consulta.id_item[0]='\0';
    consulta.articulo[0]='\0';
    consulta.producto[0]='\0';
    consulta.marca[0]='\0';

    int bandera[4] = {0, 0, 0, 0};

    FILE *fp;
    fp = fopen( "articulos.txt", "r" );
    if(fp == NULL) {printf("File error"); exit(1);}
    else printf("\nArchivo encontrado\n\n");

    int fd;
    fd = open("/tmp/mififo", O_RDONLY);
    read(fd, &consulta, sizeof(struct archivocsv));
    close(fd);

    if(consulta.id_item[0]!='\0')
        bandera[0]=1;
    if(consulta.articulo[0]!='\0')
        bandera[1]=1;
    if(consulta.producto[0]!='\0')
        bandera[2]=1;
    if(consulta.marca[0]!='\0')
        bandera[3]=1;

    char linea[500];
    char *aux;

    aux = strrchr(consulta.id_item, '=');
    strcpy(consulta.id_item, aux+1);

    aux = strrchr(consulta.articulo, '=');
    strcpy(consulta.articulo, aux+1);

    aux = strrchr(consulta.producto, '=');
    strcpy(consulta.producto, aux+1);

    aux = strrchr(consulta.marca, '=');
    strcpy(consulta.marca, aux+1);

    while(fgets(linea, sizeof(linea), fp)){
    /*Marca*/
    aux = strtok(strrchr(linea, ';'), "\n");
    strcpy(campoarchivo.marca, aux+1);
    *aux = '\0';
    /*Producto*/
    aux = strrchr(linea, ';');
    strcpy(campoarchivo.producto, aux+1);
    *aux = '\0';
    /*Articulo*/
    aux = strrchr(linea, ';');
    strcpy(campoarchivo.articulo, aux+1);
    *aux = '\0';
    /*Item*/
    sscanf(linea, "%10s", campoarchivo.id_item);

    /*if(strcmp(campoarchivo.id_item, consulta.id_item) == 0 &&
    strcmp(campoarchivo.articulo, consulta.articulo) == 0 &&
    strcmp(campoarchivo.producto, consulta.producto) == 0 &&
    strcmp(campoarchivo.marca, consulta.marca) == 0) */
    if(strcmp(campoarchivo.id_item, consulta.id_item) != 0 || bandera[0] == 0)
        continue;
    if(strcmp(campoarchivo.articulo, consulta.articulo) != 0 || bandera[1] == 0)
        continue;
    if(strcmp(campoarchivo.producto, consulta.producto) != 0 || bandera[2] == 0)
        continue;
    if(strcmp(campoarchivo.marca, consulta.marca) != 0 || bandera[3] == 0)
        continue;

    printf("Item: %s, ", campoarchivo.id_item);
    printf("Art: %s, ", campoarchivo.articulo);
    printf("Producto: %s, ", campoarchivo.producto);
    printf("Marca: %s\n\n", campoarchivo.marca);

    }
    fclose(fp);

    return 0;
}
