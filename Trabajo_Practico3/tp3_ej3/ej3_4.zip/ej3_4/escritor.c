#include <sys/stat.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include <stdio.h>
#include <string.h>

struct info
  {
      char id_item[100];
      char articulo[100];
      char producto[100];
      char marca[100];
  } consulta;

int main(void)
{

  int fd;

    strcpy(consulta.id_item, "ID=7600");
    strcpy(consulta.articulo, "ARTICULO=PANO EL COLOSO GRIS CONSOR");
    strcpy(consulta.producto, "PRODUCTO=PAÑO");
    strcpy(consulta.marca, "MARCA=EL COLOSO");

    mkfifo("/tmp/mififo", 0666);
    fd = open("/tmp/mififo", O_WRONLY);
    write(fd, &consulta, sizeof(struct info));
    close(fd);
    return 0;
}
