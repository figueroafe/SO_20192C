#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include <stdio.h>
#include <string.h>

struct archivocsv
  {
      char id_item[100];
      char articulo[100];
      char producto[100];
      char marca[100];
  } campoarchivo;

int main(void)
{
    FILE *fp;
    fp = fopen( "articulos.txt", "r" );
    if(fp == NULL) {printf("File error"); exit(1);} else printf("Archivo encontrado!\n");

    char linea[500];
    char *aux;
    while(fgets(linea, sizeof(linea), fp)){
    /*Marca*/
    aux = strrchr(linea, ';');
    //sscanf(aux+1, "%s", campoarchivo.marca);
    strcpy(campoarchivo.marca, aux+1);
    *aux = '\0';
     /*Producto*/
    aux = strrchr(linea, ';');
    //sscanf(aux+1, "%s", campoarchivo.producto);
    strcpy(campoarchivo.producto, aux+1);
    *aux = '\0';
     /*Articulo*/
    aux = strrchr(linea, ';');
    //sscanf(aux+1, "%s", campoarchivo.articulo);
    strcpy(campoarchivo.articulo, aux+1);
    *aux = '\0';
     /*Item*/
    sscanf(linea, "%10s", campoarchivo.id_item);

    printf("Item: %s, ", campoarchivo.id_item);
    printf("Art: %s, ", campoarchivo.articulo);
    printf("Producto: %s, ", campoarchivo.producto);
    printf("Marca: %s\n", campoarchivo.marca);
    }
    fclose(fp);
    return 0;
}
