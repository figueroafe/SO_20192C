/*#include <sys/stat.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include <stdio.h>

int main(void)
{
    int fd, n;
    char buf[1024];
    fd = open("/tmp/mififo", O_RDONLY);
    n = read(fd, buf, sizeof(buf));
    printf("Nro de bytes: %d\n", n);
    printf("Mensaje recibido: %s\n", buf);
    close(fd);
    return 0;
}
*/
