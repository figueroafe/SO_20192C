#include <sys/stat.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include <stdio.h>
#include <string.h>

int main()
{
    int fd;
    char consulta[50000];
    fd = open("/tmp/resultado", O_RDONLY | O_NONBLOCK);
    int bytes;
    while(bytes = read(fd, consulta, sizeof(consulta)-1 > 0))
    {
	consulta[bytes] = 0;
	printf("consulta: %s\n", consulta);
    }
    //printf("Consulta: %s\n\n", consulta);
    	
    close(fd);
    return 0;
}
