#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include <stdio.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>

void ayuda();

int main(int argc, char *argv[])
{

    char consulta[500];
    char id_item[100];
    char articulo[100];
    char producto[100];
    char marca[100];
    char campo[100];
    char valor[100];
    char linea[500];
    char cadena[500]="\0";
    char *aux='\0';
    int contador=0;


    /*strcpy(origen, argv[1]);
    strcpy(destino, argv[2]);*/

    if(strcmp(argv[1],"-help") == 0 ){
        ayuda();
    }

    FILE *fp;
    fp = fopen( "articulos.txt", "r" );
    if(fp == NULL) {printf("File error"); exit(1);}
    else printf("\nArchivo encontrado\n\n");

    int fd1, fd2;

    fd1 = open("/tmp/consulta", O_RDONLY);
    read(fd1, consulta, sizeof(consulta));
    close(fd1);
    printf("Consulta: %s\n\n", consulta);

    //Valor
    aux = strtok(strrchr(consulta, '='), "\n");
    strcpy(valor, aux+1);
    *aux = '\0';
    printf("Valor: %s\n\n", valor);

    //Campo
    aux = strtok(consulta,"=");
    strcpy(campo, aux);
    *aux = '\0';
    printf("Campo: %s\n\n", campo);

    while(fgets(linea, sizeof(linea), fp)){

    aux = strtok(strrchr(linea, ';'), "\n");
    strcpy(marca, aux+1);
    *aux = '\0';

    aux = strrchr(linea, ';');
    strcpy(producto, aux+1);
    *aux = '\0';

    aux = strrchr(linea, ';');
    strcpy(articulo, aux+1);
    *aux = '\0';

    sscanf(linea, "%10s", id_item);

    if((strcmp(id_item, valor) == 0 && strcmp("ID_ITEM", campo) == 0) ||
    (strcmp(articulo, valor) == 0 && strcmp("ARTICULO", campo) == 0) ||
    (strcmp(producto, valor) == 0 && strcmp("PRODUCTO", campo) == 0) ||
    (strcmp(marca, valor) == 0 && strcmp("MARCA", campo) == 0)){

        printf("Item: %s\n", id_item);
        printf("Articulo: %s\n", articulo);
        printf("Producto: %s\n", producto);
        printf("Marca: %s\n\n", marca);
        contador++;

        strcat(cadena, id_item);
        strcat(cadena, ";");
        strcat(cadena, articulo);
        strcat(cadena, ";");
        strcat(cadena, producto);
        strcat(cadena, ";");
        strcat(cadena, marca);
        strcat(cadena, "\n");
        }
    }
    if(contador == 0)
        printf("\nNo se registros que coincidan con la busqueda\n\n");
    else
        {
        printf("%s\n\n", cadena);
        mkfifo("/tmp/resultado", 0666);
        fd2 = open("/tmp/resultado", O_WRONLY);
        write(fd2, cadena, sizeof(cadena));
        close(fd2);
        }

    fclose(fp);

    return 0;
}

void ayuda(){

    printf("\n------------------------------------------------------------------------------\n");
    printf("----------------------------Ayuda Ejercicio 3---------------------------------\n");
    printf("------------------------------------------------------------------------------\n");
    printf("\nDescripción\n");
    printf("El demonio lee de un FIFO las consultas y devuelve por\n");
    printf("otro FIFO los registros coincidentes que encuentre. Toma por\n");
    printf("parámetro la ruta y nombre de los FIFO y los crea de ser necesario.\n");
    printf("\nParámetros\n");
    printf("Origen: Ruta del FIFO donde se buscan las consultas realizadas (una a la vez).\n");
    printf("Destino: Ruta del FIFO donde se arrojan los resultados de las consultas.\n");
    printf("-Detener: Detiene al proceso demonio.\n");
    printf("\nEjemplos:\n");
    printf("./demo /tmp/consultas /tmp/resultados\n\n");

    exit(3);

}
