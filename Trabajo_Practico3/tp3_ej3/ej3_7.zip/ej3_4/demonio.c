#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include <stdio.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <errno.h>
#include <stddef.h>

void ayuda();
int existeArchivo(char *);

/****************************** MAIN ********************************/

int main(int argc, char *argv[])
{

    char consulta[500];
    char id_item[100];
    char articulo[100];
    char producto[100];
    char marca[100];
    char campo[100];
    char valor[100];
    char linea[500];
    char cadena[500]="\0";
    char *aux='\0';
    int contador=0;
    int fd1, fd2, i;
    FILE *fp1, *fp2;
    pid_t pid, sid;

/****************************** VALIDACIONES ***************************

    if(argc == 1){
        printf("\nParámetros insuficientes, consulte ayuda con -help\n\n");
        return 1;
    }

    if(argc > 3){
        printf("\nDemasiados parámetros, consulte ayuda con -help\n\n");
        return 1;
    }

    if(strcmp(argv[1],"-help") == 0 && argc == 2){
        ayuda();
        return 1;
    }

/****************************** DEMONIO ********************************

    pid = fork();

    if (pid != 0){
        return 1;
    }

    else{
        fp1 = fopen("demonio.txt", "w");
        fprintf(fp1,"%d",getpid());
        umask(0);
        sid = setsid();

        if(sid < 0){
            perror("new SID failed");
            exit(EXIT_FAILURE);
        }

        fclose(fp1);

        chdir("/home");
        close(STDIN_FILENO);
        close(STDOUT_FILENO);
        close(STDERR_FILENO);

****************************** MANEJO DE ARCHIVOS ****************************/

        while(1){

            fp2 = fopen( "articulos.txt", "r" );
            if(fp2 == NULL){
                printf("No se encontró el archivo de artículos\n\n");
                return 1;
            }

            printf("\nEsperando consulta ...\n");
            fd1 = open("/tmp/consulta", O_RDONLY);
            read(fd1, consulta, sizeof(consulta));

            aux=strrchr(consulta, '=');
            if(aux == NULL){
                printf("\nRevise la consulta, debe tener formato CAMPO=VALOR\n\n");
                continue;
            }

            aux = strtok(aux, "\n");
            strcpy(valor, aux+1);
            *aux = '\0';
//            printf("%s\n", valor);

            aux = strtok(consulta,"=");
            strcpy(campo, aux);
            *aux = '\0';
//            printf("%s\n", campo);

            close(fd1);

            mkfifo("/tmp/resultado", 0666);
            fd2 = open("/tmp/resultado", O_WRONLY | O_NONBLOCK);

            while(fgets(linea, sizeof(linea), fp2)){

                aux = strrchr(linea, 'r');
                if(aux != NULL){
                    aux=strtok(strrchr(linea, ';'), "\r");
                    strcpy(marca, aux+1);
                    *aux = '\0';
                }

                else{
                    aux=strtok(strrchr(linea, ';'), "\n");
                    strcpy(marca, aux+1);
                    *aux = '\0';
                }

                strcpy(marca, aux+1);
                *aux = '\0';

                aux = strrchr(linea, ';');
                strcpy(producto, aux+1);
                *aux = '\0';

                aux = strrchr(linea, ';');
                strcpy(articulo, aux+1);
                *aux = '\0';

                sscanf(linea, "%10s", id_item);

                if((strcmp(id_item, valor) == 0 && strcmp("ITEM_ID", campo) == 0) ||
                    (strcmp(articulo, valor) == 0 && strcmp("ARTICULO", campo) == 0) ||
                    (strcmp(producto, valor) == 0 && strcmp("PRODUCTO", campo) == 0) ||
                    (strcmp(marca, valor) == 0 && strcmp("MARCA", campo) == 0)){

                    contador++;

                    /*printf("%s\n", id_item);
                    printf("%s\n", articulo);
                    printf("%s\n", producto);
                    printf("%s\n", marca);
                    printf("%d\n", contador);*/

                    strcat(cadena, id_item);
                    strcat(cadena, ";");
                    strcat(cadena, articulo);
                    strcat(cadena, ";");
                    strcat(cadena, producto);
                    strcat(cadena, ";");
                    strcat(cadena, marca);
                    strcat(cadena, "\n");
                    write(fd2, cadena, strlen(cadena));
                    cadena[0]='\0';

                }
            }
            close(fd2);
            fclose(fp2);

/****************************** FIFO DE SALIDA ********************************/

            if(contador == 0)
                printf("\nNo se registros que coincidan con la búsqueda\n\n");

            else{
                printf("La consulta fue resuelta con éxito.\n\n");
                printf("Esperando que el resultado sea leído ...\n");

                printf("El resultado fue leído.\n\n");

            }
        }
    //}
    return 0;
}
    /*strcpy(origen, argv[1]);
    strcpy(destino, argv[2]);*/

    /*if(existeArchivo(argv[1]) == 0){
        mkfifo(argv[1], 0666);
    }

    if(existeArchivo(argv[2]) == 0){
        mkfifo(argv[2], 0666);
    }*/

/****************************** FUNCIONES ******************************/

void ayuda(){

    printf("\n--------------------------------------------------------------------------------\n");
    printf("--------------------------- Ayuda Ejercicio 3 ----------------------------------\n");
    printf("--------------------------------------------------------------------------------\n");
    printf("\nDescripción\n");
    printf("El demonio lee de un FIFO las consultas y devuelve por\n");
    printf("otro FIFO los registros coincidentes que encuentre. Toma por\n");
    printf("parámetro la ruta y nombre de los FIFO y los crea de ser necesario.\n");
    printf("\nParámetros\n");
    printf("Origen: Ruta del FIFO donde se buscan las consultas realizadas (una a la vez).\n");
    printf("Destino: Ruta del FIFO donde se arrojan los resultados de las consultas.\n");
    printf("-detener: Detiene el proceso demonio.\n");
    printf("\nSintáxis\n");
    printf("./script [origen] [destino]\n");
    printf("./script -detener\n");
    printf("\nEjemplos\n");
    printf("./demo /tmp/consultas /tmp/resultados\n");
    printf("./demo -detener\n\n");

}

int existeArchivo(char *ruta)
{
  int fd=open(ruta, O_RDONLY | O_NONBLOCK);
  if (fd<0)
    return 0;
  close(fd);
  return 1;
}
