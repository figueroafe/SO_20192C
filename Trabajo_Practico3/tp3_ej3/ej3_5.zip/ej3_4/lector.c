#include <sys/stat.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include <stdio.h>
#include <string.h>

int main(void)
{

    struct info
	{
		char item_id[1024];
		char articulo[1024];
		char producto[1024];
		char marca[1024];
	};

    struct info consulta;

    int fd, n;
    fd = open("/tmp/mififo", O_RDONLY);
    n = read(fd, &consulta, sizeof(struct info));
    printf("Nro de bytes: %d\n", n);
    printf("Mensaje recibido: %s, %s, %s, %s\n", consulta.item_id, consulta.articulo, consulta.producto, consulta.marca);
    close(fd);
    return 0;
}
