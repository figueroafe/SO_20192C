/*#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include <stdio.h>
#include <string.h>

struct archivocsv
  {
      int id_item;
      char articulo[100];
      char producto[100];
      char marca[100];
  } campoarchivo;

/*int main(void)
{
    FILE *fp;
    fp = fopen( "articulos.txt", "r" );
    if(fp == NULL) {printf("File error"); exit(1);} else printf("Archivo encontrado!\n");

    char linea[500];
    char *aux;
    fgets(linea, sizeof(linea-1), fp);
    int ci = 0;
    while(ci < 5){
    aux = strrchr(linea, ';');
    sscanf(aux, "%s", campoarchivo.marca);
    *aux = '\0';
    printf("Marca: %s\n", linea);
    fgets(linea, sizeof(linea-1), fp);
    ci++;
    }
    fclose(fp);
    return 0;
}
*/
