#include <sys/stat.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include <stdio.h>
#include <string.h>

int main()
{	
    int fd;
    mkfifo("/tmp/consulta", 0666);
    fd = open("/tmp/consulta", O_WRONLY);
    write(fd, "MARCA=GEORGALOS", sizeof("MARCA=GEORGALOS"));
    close(fd);
    return 0;
}
