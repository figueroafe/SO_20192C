#include <sys/stat.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include <stdio.h>

int main(void)
{
    int fd;
    char buf[] = "hola";
    mkfifo("/tmp/mififo", 0666);
    fd = open("/tmp/mififo", O_WRONLY);
    write(fd, buf, sizeof(buf));
    close(fd);
    return 0;
}
