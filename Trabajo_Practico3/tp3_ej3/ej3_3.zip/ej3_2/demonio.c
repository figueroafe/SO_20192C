#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include <stdio.h>
#include <string.h>

struct archivocsv
  {
      char id_item[100];
      char articulo[100];
      char producto[100];
      char marca[100];
  } campoarchivo;

 struct info
  {
      char id_item[100];
      char articulo[100];
      char producto[100];
      char marca[100];
  } consulta;


int main(void)
{
    FILE *fp;
    fp = fopen( "articulos.txt", "r" );
    if(fp == NULL) {printf("File error"); exit(1);} else printf("Archivo encontrado!\n");

    int fd;
    fd = open("/tmp/mififo", O_RDONLY);
    read(fd, &consulta, sizeof(struct archivocsv));
    printf("Mensaje recibido: %s, %s, %s, %s\n", consulta.id_item, consulta.articulo, consulta.producto, consulta.marca);
    close(fd);

    char linea[500];
    char *aux;

    aux = strrchr(consulta.id_item, '=');
    strcpy(consulta.id_item, aux+1);

    aux = strrchr(consulta.articulo, '=');
    strcpy(consulta.articulo, aux+1);

    aux = strrchr(consulta.producto, '=');
    strcpy(consulta.producto, aux+1);

    aux = strrchr(consulta.marca, '=');
    strcpy(consulta.marca, aux+1);

    while(fgets(linea, sizeof(linea), fp)){
    /*Marca*/
    aux = strrchr(linea, ';');
    //sscanf(aux+1, "%s", campoarchivo.marca);
    strcpy(campoarchivo.marca, aux+1);
    *aux = '\0';
     /*Producto*/
    aux = strrchr(linea, ';');
    //sscanf(aux+1, "%s", campoarchivo.producto);
    strcpy(campoarchivo.producto, aux+1);
    *aux = '\0';
     /*Articulo*/
    aux = strrchr(linea, ';');
    //sscanf(aux+1, "%s", campoarchivo.articulo);
    strcpy(campoarchivo.articulo, aux+1);
    *aux = '\0';
    /*Item*/
    sscanf(linea, "%10s", campoarchivo.id_item);


    sscanf(linea, "%10s", campoarchivo.id_item);
    printf("Item: %s, ", campoarchivo.id_item);
    printf("Art: %s, ", campoarchivo.articulo);
    printf("Producto: %s, ", campoarchivo.producto);
    printf("Marca: %s\n", campoarchivo.marca);
    printf("**VS**\n");
    printf("Item: %s, ", consulta.id_item);
    printf("Art: %s, ", consulta.articulo);
    printf("Producto: %s, ", consulta.producto);
    printf("Marca: %s\n", consulta.marca);
    printf("----------------------------------\n");

    if(strcmp(campoarchivo.id_item, consulta.id_item) == 0 &&
    strcmp(campoarchivo.articulo, consulta.articulo) == 0 &&
    strcmp(campoarchivo.producto, consulta.producto) == 0 &&
    strcmp(campoarchivo.marca, consulta.marca) == 0) {

    printf("Item: %s, ", campoarchivo.id_item);
    printf("Art: %s, ", campoarchivo.articulo);
    printf("Producto: %s, ", campoarchivo.producto);
    printf("Marca: %s\n", campoarchivo.marca);

        }

    }
    fclose(fp);

    return 0;
}
