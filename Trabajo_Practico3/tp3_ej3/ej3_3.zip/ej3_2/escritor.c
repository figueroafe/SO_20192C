#include <sys/stat.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include <stdio.h>
#include <string.h>

int main(void)
{
    struct info
  {
      char id_item[100];
      char articulo[100];
      char producto[100];
      char marca[100];
  } consulta;

  int fd;

    strcpy(consulta.id_item, "ID=16008");
    strcpy(consulta.articulo, "ARTICULO=P.DULCE GEORGALOS POUCH 700 gr");
    strcpy(consulta.producto, "PRODUCTO=P.DULCE");
    strcpy(consulta.marca, "MARCA=GEORGALOS");

    mkfifo("/tmp/mififo", 0666);
    fd = open("/tmp/mififo", O_WRONLY);
    write(fd, &consulta, sizeof(struct info));
    close(fd);
    return 0;
}
