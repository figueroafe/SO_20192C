#ifndef SEMAFORO_H_INCLUDED
#define SEMAFORO_H_INCLUDED

void pedirSemaforo(int);
void devolverSemaforo(int);

union semun {
        int val;
        struct semid_ds *buf;
        ushort *array;
} arg;

#endif // SEMAFORO_H_INCLUDED
