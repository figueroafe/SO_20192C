#include <stdio.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/shm.h>
#include <string.h>
#include <errno.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <unistd.h>
#include <sys/types.h>
#include <signal.h>
#include <semaphore.h>
#include <sys/stat.h>
#include <time.h>
#include <sys/ipc.h>
#include </home/adrian/Escritorio/tp3_ej4/semaforo.h>

void ayuda(void);

int main(int argc, char *argv[])
{
    /*//VALIDACIONES
    if(argc != 2){
        printf("\nCantidad de parámetros incorrectos, consulte ayuda con %s -help.\n\n", argv[0]);
        return 1;
    }

    else{

        if(strcmp(argv[1],"-help") == 0){
            ayuda();
            return 1;
        }

    }*/
    //BUSCA EL ESPACIO DE MEMORIA COMPARTIDA
    key_t clave;
    int shmid;
    clave = ftok("/tmp", 'L');
    shmid = shmget(clave, 65536, 0660);

    //MAPEO DEL ESPACIO DE MEMORIA COMPARTIDA
    char *buffer;
    buffer = (char *)shmat(shmid, NULL, 0);
    strcpy(buffer, argv[1]);
    sleep(20);
    puts(buffer);
    shmdt(buffer);

}
    //FUNCIONES
void ayuda(){

    printf("\n-------------------------------------------------------------------------------\n");
    printf("--------------------------- Ayuda Ejercicio 4 ---------------------------------\n");
    printf("-------------------------------------------------------------------------------\n");
    printf("\nDescripción\n");
    printf("El proceso lee de un espacio de memoria compartida las consultas y\n");
    printf("devuelve por pantalla los registros coincidentes que encuentre. Toma\n");
    printf("por parámetro la consulta con formato CAMPO=VALOR.\n");
    printf("\nParámetros\n");
    printf("Consulta: Consulta a realizar.\n");
    printf("\nSintáxis\n");
    printf("./tp3_ej4 [consulta]\n");
    printf("\nEjemplos\n");
    printf("./tp3_ej4 MARCA=GEORGALOS\n\n");
}
