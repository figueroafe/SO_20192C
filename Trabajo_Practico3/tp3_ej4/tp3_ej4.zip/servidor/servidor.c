#include <stdio.h>
#include <stdlib.h>
#include <sys/shm.h>
#include <string.h>
#include <errno.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <unistd.h>
#include <sys/types.h>
#include <signal.h>
#include <semaphore.h>
#include <sys/stat.h>
#include <time.h>

sem_t* mutex_0, *mutex_1, *mutex_2;
int fd;
char *buffer;

int main()
{
    char *aux='\0';
    char id_item[100];
    char articulo[100];
    char producto[100];
    char marca[100];
    char campo[100];
    char valor[100];
    char linea[500];
    FILE *fp;
    int contador=0, consultas = 0;

    fd = shm_open("shm", O_CREAT | O_EXCL | O_RDWR, 0600); //creacion de memoria compartida
    ftruncate(fd, 65536);
	mutex_0 = sem_open("mutex_0", O_CREAT, 0777, 0); //creacion de semaforo
	mutex_1 = sem_open("mutex_1", O_CREAT, 0777, 1); //creacion de semaforo
	mutex_2 = sem_open("mutex_2", O_CREAT, 0777, 0); //creacion de semaforo

while(consultas < 3){

    printf("Pidiendo semaforo de lectura...\n");
    sem_wait(mutex_0);
    printf("Semaforo obtenido, leyendo consulta...\n");
    buffer = (char *) mmap(0, 65536, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
    printf("\nconsulta recibida: %s\n\n", buffer);
    aux=strrchr(buffer, '=');
    if(aux == NULL){
        strcpy(buffer, "\nRevise la consulta, debe tener formato CAMPO=VALOR\n");
        shm_unlink("shm");
        return 1;
    }

    aux = strtok(aux, "\n");
    strcpy(valor, aux+1);
    *aux = '\0';

    aux = strtok(buffer,"=");
    strcpy(campo, aux);
    *aux = '\0';

    fp = fopen("/tmp/articulos.txt", "r");
    if(fp == NULL){
        printf("\nNo se encontró el archivo de artículos, revise la ubicación.\n");
        shm_unlink("shm");
        return 1;
    }

    buffer[0] = '\0';
    printf("Buscando coincidencias...\n");
    sleep(20);
    while(fgets(linea, sizeof(linea), fp)){

        aux = strrchr(linea, '\r');
        if(aux != NULL){
            aux=strtok(strrchr(linea, ';'), "\r");
            strcpy(marca, aux+1);
            *aux = '\0';
        }

        else{
            aux=strtok(strrchr(linea, ';'), "\n");
            strcpy(marca, aux+1);
            *aux = '\0';
        }

        strcpy(marca, aux+1);
        *aux = '\0';

        aux = strrchr(linea, ';');
        strcpy(producto, aux+1);
        *aux = '\0';

        aux = strrchr(linea, ';');
        strcpy(articulo, aux+1);
        *aux = '\0';

        sscanf(linea, "%10s", id_item);

        if((strcmp(id_item, valor) == 0 && strcmp("ITEM_ID", campo) == 0) ||
            (strcmp(articulo, valor) == 0 && strcmp("ARTICULO", campo) == 0) ||
            (strcmp(producto, valor) == 0 && strcmp("PRODUCTO", campo) == 0) ||
            (strcmp(marca, valor) == 0 && strcmp("MARCA", campo) == 0)){

            contador++;

            strcat(buffer, id_item);
            strcat(buffer, ";");
            strcat(buffer, articulo);
            strcat(buffer, ";");
            strcat(buffer, producto);
            strcat(buffer, ";");
            strcat(buffer, marca);
            strcat(buffer, "\n");

        }

    }

    if(contador == 0)
            strcpy(buffer, "\nNo se encontraron registros que coincidan con la búsqueda.\n\n");

    rewind(fp);    
    printf("Enviando respuesta...\n");
    sem_post(mutex_2);
    printf("Semaforo de lectura de buffer liberado...\n");
    consultas++;
}
    fclose(fp);
    shm_unlink("shm");
    return(1);
}

