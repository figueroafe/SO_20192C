#include<sys/types.h>
#include<sys/ipc.h>
#include<sys/shm.h>
#include<sys/stat.h>
#include<sys/sem.h>
#include<fcntl.h>
#include<stdio.h>
#include<signal.h>

int main () {
    return 1;
}
