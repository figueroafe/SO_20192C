#ifndef SEMAFORO_H_INCLUDED
#define SEMAFORO_H_INCLUDED
#include<sys/types.h>
#include<sys/ipc.h>
#include<sys/shm.h>
#include<sys/stat.h>
#include<sys/sem.h>
#include<fcntl.h>
#include<stdio.h>
#include<signal.h>

union semun {
int val;
struct semid_ds *buf;
unsigned short *array;
struct seminfo *__buf;
};

void pedirSemaforo(int);
void devolverSemaforo(int);


#endif // SEMAFORO_H_INCLUDED
