#include </home/fernando/Escritorio/tp3_ej4_SemBeta/tp3_ej4/semaforos/semaforo.h>

void pedirSemaforo(int IdSemaforo) {
    struct sembuf OpSem;
    OpSem.sem_num = 0;
    OpSem.sem_op = -1;
    OpSem.sem_flg = 0;
    semop(IdSemaforo, &OpSem, 1);
}

void devolverSemaforo(int IdSemaforo) {
    struct sembuf OpSem;
    OpSem.sem_num = 0;
    OpSem.sem_op = 1;
    OpSem.sem_flg = 0;
    semop(IdSemaforo, &OpSem, 1);
}
