#include <sys/types.h>
#include <sys/stat.h>
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <errno.h>
#include <unistd.h>
#include <syslog.h>
#include <string.h>

int main()
{
    pid_t pid, sid;

    pid = fork();

    if (pid != 0){
    exit(1);
    }
    else
    {
    FILE *fp;
    fp = fopen( "demonio.txt", "w" );

    //int valor = getpid();
    fprintf(fp,"%d",getpid());
    umask(0);
    sid = setsid();

    if (sid < 0) {
    perror("new SID failed");
    exit(EXIT_FAILURE);
    }

    chdir("/home");
    close(STDIN_FILENO);
    close(STDOUT_FILENO);
    close(STDERR_FILENO);

    while(1)
    {
      sleep(30);
    }

    }

    return 0;
}
