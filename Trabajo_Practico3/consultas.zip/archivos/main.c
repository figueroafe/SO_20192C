#include <stdio.h>
#include <string.h>
#include <time.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <sys/stat.h>
#include <stdlib.h>
#include <fcntl.h>
#include <errno.h>
#include <unistd.h>
#include <syslog.h>
#include <signal.h>
#include <stddef.h>
int main()
{

        FILE *fp, *fp2;
        char *aux;
        char campo[100];
        char valor[100];
        char id_item[100];
        char articulo[100];
        char producto[100];
        char marca[100];
        char recevBuff[1024];
        char linea[500];
        char cadena[500]="\0";
        fp = fopen("/tmp/resultados", "w");
        fp2 = fopen("/tmp/articulos.txt", "r");

        strcpy(recevBuff, "MARCA=MAROLIO");

        //Valor
        aux = strrchr(recevBuff, '=');

        if(aux == NULL)
        {
            printf("Esta mal viejo");
            exit(1);
        }
        else
        {
            aux = strtok(aux, "\n");
            strcpy(valor, aux+1);
            *aux = '\0';
            //Campo
            aux = strtok(recevBuff,"=");
            strcpy(campo, aux);
            *aux = '\0';
            //fprintf(fp2,"%s;%s\n",campo, valor);
        }



        while(fgets(linea, sizeof(linea), fp2))
        {

            aux = strrchr(linea, '\r');
            if(aux != NULL)
            {
                aux = strtok(strrchr(linea, ';'), "\r");
                strcpy(marca, aux+1);
                *aux = '\0';
            }
            else
            {
                aux = strtok(strrchr(linea, ';'), "\n");
                strcpy(marca, aux+1);
                *aux = '\0';
            }

            aux = strrchr(linea, ';');
            strcpy(producto, aux+1);
            *aux = '\0';

            aux = strrchr(linea, ';');
            strcpy(articulo, aux+1);
            *aux = '\0';

            sscanf(linea, "%10s", id_item);

            if((strcmp(id_item, valor) == 0 && strcmp("ITEM_ID", campo) == 0) ||
            (strcmp(articulo, valor) == 0 && strcmp("ARTICULO", campo) == 0) ||
            (strcmp(producto, valor) == 0 && strcmp("PRODUCTO", campo) == 0) ||
            (strcmp(marca, valor) == 0 && strcmp("MARCA", campo) == 0)){

                strcat(cadena, id_item);
                strcat(cadena, ";");
                strcat(cadena, articulo);
                strcat(cadena, ";");
                strcat(cadena, producto);
                strcat(cadena, ";");
                strcat(cadena, marca);
                strcat(cadena, "\r\n\0");
                fprintf(fp,"%s",cadena);
                cadena[0] = '\0';
                }
        }
        fclose(fp);
        fclose(fp2);
        return 1;
}
