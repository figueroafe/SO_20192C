#! /bin/bash

#-----------------------Inicio Encabezado------------------------------##
# Nombre Script: "ej_1.sh"
# Numero Trabajo Practico: 1 
# Numero Ejercicio: 1
# Tipo: 1° Entrega
# Integrantes:
#
#		Nombre y Apellido                                 DNI
#		---------------------                           --------
#       Federico Martín Medina                          36.822.613
#       Marcelo Romero                                  34.140.911
#       Sergio Salas                                    32.090.753                 
#       Lautaro Marino 		                	        39.457.789
#       Néstor Gabriel Escobar       	     			36.960.978
#
##-----------------------Fin del Encabezado-----------------------------##

#########################################

# Funciones

Ayuda(){
echo    
echo "El script permite realizar una busqueda dentro del archivo"
echo "Parametro -c permite busqueda por CUIT"
echo "Parametro -d permite busqueda por DNI"
echo "Parametro -n permite busqueda por nombre o parte del mismo contenido"
echo
echo "Ej: ./script.sh -d 36960978 archivoinfo.txt"
echo
}

# Fin Funciones

# Verificacion de parametros

param="mal";
if (( $# == 0 ))
then
    param="-nada";
    Ayuda
    exit
else
    if [ "$1" = "-help" -o "$1" = "-?" -o "$1" = "-h" ]
    then
        Ayuda
        exit;
    fi

    if (( $# <= 2 ))
    then
        echo "Parametros insuficientes"
        Ayuda
        exit;
    fi

    if [ "$1" = "-c" -o "$1" = "-d" -o "$1" = "-n" ]
    then
        param=$1;
    else
        echo "El 1er parametro ingresado no es correcto"
        Ayuda
        exit;
    fi

    if [ "$(dirname "$3")" = "." ]
    then
        if ! [ -f "$3" ]; 
        then
        echo "No es un archivo valido el suministrado"
        exit
        fi
    else
        if [ -d "$(dirname "$3")" ]
        then
            if [ ! -r "$(dirname "$3")" ]
            then
                echo " El directorio indicado no tiene permiso de lectura. "
                exit
            else
                cd "$(dirname "$3")"
                if ! [ -f "$(basename "$3")" ]
                then
                    echo "No es un archivo valido el suministrado"
                    exit
                fi
            fi
        else
            echo "La ruta: "$(dirname "$3")" "
            echo
            echo "No es valida"
            exit
        fi

    fi
fi

# Fin Verificacion de parametros

case $param in
    -c) fields=1
    ;;
    -d) fields=1
    ;;
    -n) fields=2
    ;;
esac    

dato="$2"
awk -v campb=$fields 'BEGIN {
FIELDWIDTHS = "11 30 2 2 2 1 1 2"
}
index($campb, "'$dato'")!=0 {
printf "\n\n"
print "Nombre                          CUIT         IMP_Gana  IMP_IVA  Monotrib  Integ_SOC  Emplea  Act_Mono"
print "------------------------------  -----------  --------  -------  --------  ---------  ------  --------"
printf "%-30s  %11s  %8s  %7s  %8s  %9s  %6s  %8s \n\n", $2, $1, $3, $4, $5, $6, $7, $8

}
index($campb, "'$dato'")==0 {
typemt[$5]++;
}
END {
printf "\n\n"
print " ----- Resumen de Tipos de Monotributo filtrados ----- "
printf "\n"
print "Tipo Mono    Cant"
print "---------    ----"
for(i in typemt)
    printf "%-9s    %4d\n",i , typemt[i]

}' "$(basename "$3")"

#########################################
